# BOLD — Ready deploy bundle

This folder is ready for Netlify deploy (static HTML + Tailwind CDN).

## Form emails → boldprodtlv@gmail.com
The form is configured for **Netlify Forms**.
After first deploy + one test submission:
Netlify Dashboard → Forms → `bold-brief` → Notifications → Add email → `boldprodtlv@gmail.com`

## Files
- `index.html` — home page
- `thanks.html` — thank-you page (after submit)
- `assets/logos/bold-logo.png` — logo
- `netlify.toml` — Netlify publish settings
